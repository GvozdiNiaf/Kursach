﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class createIDcard : Form
    {
        public createIDcard()
        {
            InitializeComponent();
        }

        private void createIDcard_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string curentIDCARD = textBox1.Text;
            string curentPath;
            curentPath = "visitors" + "\\" + curentIDCARD + "\\" + "VisitorsInfo.txt";
            FileInfo curentbookfile = new FileInfo(curentPath);
            StreamWriter curentbook = new StreamWriter(curentPath);

            curentbook.WriteLine("ФИО: " + curentIDCARD);

            curentbook.WriteLine("Адрес: " + textBox2.Text);

            curentbook.WriteLine("Номер телефона: " + textBox3.Text);

            curentbook.WriteLine("Emale: " + textBox4.Text);

            curentbook.Close();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
