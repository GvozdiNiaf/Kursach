﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class createbook : Form
    {
        public createbook()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string curentidbook = textBox1.Text;
            string curentPath;
            curentPath = "books" + "\\" + curentidbook + ".txt";
            FileInfo curentbookfile = new FileInfo(curentPath);
            StreamWriter curentbook = new StreamWriter(curentPath);

            curentbook.WriteLine("Название: " + curentidbook);

            curentbook.WriteLine("Краткое описание: " + textBox2.Text);

            curentbook.WriteLine("Год выпуска: " + textBox3.Text);

            curentbook.WriteLine("Цена книги: " + textBox4.Text);

            curentbook.WriteLine("Книг на складе: " + textBox5.Text);

            curentbook.Close();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
