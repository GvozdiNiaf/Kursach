﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class visitor : Form
    {
        private void showinfo(string CurentUservoid)
        {
            string Curentvoid = CurentUservoid;
             textBox6.Lines = File.ReadAllLines("visitors" + "\\" + Curentvoid + "\\" + "IDCARD.txt");

}

        private void savechanjes(string CurentUservoid)
        {
            string Curentvoid = CurentUservoid;
            File.WriteAllLines("visitors" + "\\" + Curentvoid + "\\" + "IDCARD.txt", textBox6.Lines);
        }
class Book
        {
            public string NameOfBook, author, shortdescription;
            public string year;
            public string coast;
            public int howmuch;
        }
        public visitor()
        {
            InitializeComponent();
        }

        private void visitor_Load(object sender, EventArgs e)
        {
            
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "Ваше ФИО") textBox1.Text = " ";
        }

        private void textBox1_Leave(object sender, EventArgs e) 
        {
            if (textBox1.Text == " ") textBox1.Text = "Ваше ФИО";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "Наименование Книги") textBox2.Text = " ";
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text == " ") textBox2.Text = "Наименование Книги";
        }
        private void textBox5_Click(object sender, EventArgs e)
        {
            if (textBox5.Text == "Наименование Книги") textBox5.Text = " ";
        }
        private void textBox5_Leave(object sender, EventArgs e)
        {
            if (textBox5.Text == " ") textBox5.Text = "Наименование Книги";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String CurentUser = textBox1.Text;
            if (Directory.Exists("visitors" + "\\" + CurentUser))
            {
                showinfo(CurentUser);
                takebutton.Visible = true;
                button2.Visible = true;
            }
        }

        private void takebutton_Click(object sender, EventArgs e)
        {
            string curentfoudedbook = textBox2.Text;
            if (File.Exists("books" + "\\" + curentfoudedbook + ".txt"))
            {
                Book curentclaimingbook = new Book();
                curentclaimingbook.NameOfBook = curentfoudedbook;
                string[] curentfile = File.ReadAllLines("books" + "\\" + curentfoudedbook + ".txt");
                curentclaimingbook.year = curentfile[2].Substring(13);
                curentclaimingbook.shortdescription = curentfile[1].Substring(18);
                curentclaimingbook.coast = curentfile[3].Substring(12);
                curentclaimingbook.howmuch = Convert.ToInt32(curentfile[4].Substring(16));
                int howmuch = curentclaimingbook.howmuch - 1;
                StreamWriter curenthowmuchbook = new StreamWriter("books" + "\\" + curentfoudedbook + ".txt");
                curenthowmuchbook.WriteLine("Название: " + curentclaimingbook.NameOfBook);
                curenthowmuchbook.WriteLine("Краткое описание: " + curentclaimingbook.shortdescription);
                curenthowmuchbook.WriteLine("Год выпуска: " + curentclaimingbook.year);
                curenthowmuchbook.WriteLine("Цена книги: " + curentclaimingbook.coast);
                curenthowmuchbook.WriteLine("Книг на складе: " + howmuch);
                curenthowmuchbook.Close();

                textBox6.Text = textBox6.Text + "\r\n" + "Взята книга: " + curentclaimingbook.NameOfBook;
                savechanjes(textBox1.Text);
            }
            else MessageBox.Show("Данной книги нет на наших складах","Ошибка");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] claimedbooks = File.ReadAllLines("visitors" + "\\" + textBox1.Text + "\\" + "IDCARD.txt");
            for (int i = 4; i < claimedbooks.Length; i++)
            {
                textBox6.Lines[i] = claimedbooks[i];
            }
            string returningbook = textBox5.Text;
            for (int u = 4; u < claimedbooks.Length; u++)
            {
               if (claimedbooks[u].Length > 0)
                if (claimedbooks[u].Substring(claimedbooks[u].Length - returningbook.Length).Trim() == returningbook)
                {
                    claimedbooks[u] = claimedbooks[u].Substring(claimedbooks[u].Length);
                }
            }
            textBox6.Lines = claimedbooks;
            savechanjes(textBox1.Text);
            showinfo(textBox1.Text);
            
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
